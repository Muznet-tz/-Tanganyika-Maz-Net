
from flask import Flask, request, jsonify
from flask_cors import CORS
import tensorflow as tf
import numpy as np
from PIL import Image
import io

app = Flask(__name__)
CORS(app)

model = tf.keras.models.load_model('model.h5')

CLASS_NAMES = ['Cow001', 'Cow002', 'Cow003', 'Cow004', 'Cow005']  # Update based on your dataset

def preprocess_image(image_bytes):
    image = Image.open(io.BytesIO(image_bytes)).convert('L').resize((128, 128))
    image = np.array(image).astype('float32') / 255.0
    image = np.expand_dims(image, axis=(0, -1))
    return image

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file = request.files['file']
    image = preprocess_image(file.read())
    prediction = model.predict(image)
    predicted_class = np.argmax(prediction, axis=1)[0]
    confidence = np.max(prediction)

    return jsonify({
        'cow_id': CLASS_NAMES[predicted_class],
        'confidence': float(confidence)
    })

if __name__ == '__main__':
    app.run(debug=True)
